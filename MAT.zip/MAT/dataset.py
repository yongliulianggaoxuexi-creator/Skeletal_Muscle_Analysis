import os
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms
import random

# --------------------------------------
# 自定义数据集类
# --------------------------------------
class SegDataset(Dataset):
    def __init__(self, root_dir, split='train', transform=None, random_seed=42):
        """
            root_dir: 数据集根目录（包含 images 和 labels 文件夹）
            split: 'train' 或 'test'，用于划分数据集
            transform: 数据增强变换
            random_seed: 随机种子，确保划分可重复
        """
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.image_dir = os.path.join(root_dir, split, 'images')
        self.label_dir = os.path.join(root_dir, split, 'masks')

        # 获取所有患者文件夹
        self.all_images = sorted(os.listdir(self.image_dir))

        random.seed(random_seed)

        # 随机打乱
        random.shuffle(self.all_images)

        # 收集所有图像和标签路径
        self.image_paths = []
        self.label_paths = []
        for img_file in self.all_images:
            if img_file.endswith('.png'):
                self.image_paths.append(os.path.join(self.image_dir, img_file))
                mask_file = img_file
                self.label_paths.append(os.path.join(self.label_dir, mask_file))




    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        # 读取图像
        img_path = self.image_paths[idx]
        label_path = self.label_paths[idx]
        image = Image.open(img_path).convert('RGB')  # 转换为RGB
        label = Image.open(label_path).convert('L')  # 灰度图

        # 转换为numpy数组
        image = np.array(image)
        label = np.array(label)

        # 将标签从{0,127,255}转换为{0,1,2}
        label = np.where(label == 255, 2, np.where(label == 127, 1, 0)).astype(np.uint8)

        # 应用数据增强
        if self.transform:
            augmented = self.transform(image=image, mask=label)
            image = augmented['image']
            label = augmented['mask']

        # 转换为PyTorch张量
        image = transforms.ToTensor()(image)  # 归一化到[0,1]
        label = torch.from_numpy(label).long()

        return image, label


def visualize_pixel_matrix(pixel_matrix, title='gray Image'):
    from matplotlib import pyplot as plt
    plt.figure(figsize=(6, 3))
    plt.imshow(pixel_matrix, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.show()