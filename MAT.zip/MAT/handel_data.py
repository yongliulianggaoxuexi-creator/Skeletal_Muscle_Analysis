import random
import shutil
from itertools import count

import cv2
import nrrd
import numpy as np
from PIL import Image
import os
import pydicom
import matplotlib.pyplot as plt

def visualize_pixel_matrix(pixel_matrix, title='gray Image'):
    plt.figure(figsize=(6, 3))
    plt.imshow(pixel_matrix, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.show()


def nrrd_to_png(input_path, output_folder):
    # 创建输出目录
    os.makedirs(output_folder, exist_ok=True)

    # 读取NRRD文件
    data, header = nrrd.read(input_path)
    print("原始数据维度:", data.shape)
    count = 0

    # 处理三维数据（假设维度顺序为 [slice, height, width]）
    if len(data.shape) == 3:
        # 遍历每个切片（第三维度）
        for slice_idx in range(data.shape[2]):
            slice_data = data[:, :, slice_idx]

            rotated_slice = np.rot90(slice_data, k=-1)  # k=-1表示顺时针旋转90度

            # 归一化当前切片
            slice_normalized = (rotated_slice - np.min(data)) / (np.max(data) - np.min(data)) * 255
            image_data = slice_normalized.astype(np.uint8)

            # 创建并保存PNG
            base_name = os.path.basename(input_path).replace('.nrrd', '')
            output_path = os.path.join(output_folder, f"{base_name}_slice{slice_idx:03d}.png")
            if np.unique(image_data).size > 1:
                Image.fromarray(image_data, mode='L').save(output_path)
                count += 1

        print(f"转换完成，共保存 {count} 个切片")
    else:
        # 确保二维数据格式
        if len(data.shape) != 2:
            raise ValueError(f"无法处理 {len(data.shape)}D 数据，请检查输入文件维度")

        # 归一化到0-255范围（添加数据类型转换）
        data_normalized = (data - np.min(data)) / (np.max(data) - np.min(data)) * 255
        image_data = data_normalized.astype(np.uint8)

        # 创建并保存PNG（添加L模式指定灰度图像）
        img = Image.fromarray(image_data, mode='L')  # 添加模式参数
        output_path = os.path.join(output_folder, os.path.basename(input_path).replace('.nrrd', '.png'))
        img.save(output_path)
        print(f"转换完成: {output_path}")



def process_all_nrrd(input_root, output_root):
    # 遍历 train/PatientXXX 文件夹
    for patient_name in os.listdir(input_root):
        patient_dir = os.path.join(input_root, patient_name)
        if not os.path.isdir(patient_dir):
            continue

        output_patient_dir = os.path.join(output_root, patient_name)
        os.makedirs(output_patient_dir, exist_ok=True)

        for filename in os.listdir(patient_dir):
            if filename.endswith(".nrrd"):
                input_path = os.path.join(patient_dir, filename)
                nrrd_to_png(input_path, output_patient_dir)

    print("\n✅ 全部 .nrrd 文件已处理完成")


def rename():
    import os

    # 设置你的根目录路径
    root_dir = r"E:\dataset\MAT\MAT\train_png"

    for patient_name in os.listdir(root_dir):
        patient_dir = os.path.join(root_dir, patient_name)
        if not os.path.isdir(patient_dir):
            continue

        # 获取所有 .png 文件，按文件名排序（确保顺序正确）
        png_files = sorted([f for f in os.listdir(patient_dir) if f.endswith(".png")])
        if len(png_files) < 2:
            print(f"{patient_name} 中的图片不足两张，跳过")
            continue

        # 构造原始路径和目标路径
        src_image = os.path.join(patient_dir, png_files[0])
        dst_image = os.path.join(patient_dir, "image.png")

        src_mask = os.path.join(patient_dir, png_files[1])
        dst_mask = os.path.join(patient_dir, "mask.png")

        # 重命名
        os.rename(src_image, dst_image)
        os.rename(src_mask, dst_mask)

        print(f"{patient_name} 已重命名为 image.png 和 mask.png")


def rename_file():
    folder_path = 'E:\dataset\MAT\masks'

    # 遍历该目录下的所有文件
    for filename in os.listdir(folder_path):
        if filename.endswith('_mask.png'):
            old_path = os.path.join(folder_path, filename)
            # 移除 "_image" 的部分
            new_filename = filename.replace('_mask.png', '.png')
            new_path = os.path.join(folder_path, new_filename)
            os.rename(old_path, new_path)
            print(f'Renamed: {filename} -> {new_filename}')


def read_dicom(input_path, output_folder):

    ds = pydicom.dcmread(input_path)
    slice = ds.pixel_array
    slice_normalized = (slice - np.min(slice)) / (np.max(slice) - np.min(slice)) * 255
    image_data = slice_normalized.astype(np.uint8)
    # 创建并保存PNG

    base_name = os.path.basename(input_path)
    if base_name.endswith(".dcm") :
        base_name, _ = os.path.splitext(base_name)
    output_path = os.path.join(output_folder, f"{base_name}.png")
    Image.fromarray(image_data, mode='L').save(output_path)

def process_all_dicom(input_root, output_root):
    # 遍历 train/PatientXXX 文件夹
    count = 0
    for patient_name in os.listdir(input_root):
        patient_dir = os.path.join(input_root, patient_name)
        if not os.path.isdir(patient_dir):
            continue

        output_patient_dir = os.path.join(output_root, patient_name)
        os.makedirs(output_patient_dir, exist_ok=True)

        for filename in os.listdir(patient_dir):
            input_path = os.path.join(patient_dir, filename)
            read_dicom(input_path, output_patient_dir)
            count += 1

    print("\n✅ 共处理 {} 个 DICOM 文件".format(count))


def move_file():
    import os
    import shutil

    root_dir = r"E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片"  # 修改成你的MAT路径

    for patient in os.listdir(root_dir):
        patient_path = os.path.join(root_dir, patient)
        if not os.path.isdir(patient_path):
            continue

        # 遍历病人子目录
        for sub in os.listdir(patient_path):
            sub_path = os.path.join(patient_path, sub)
            if not os.path.isdir(sub_path):
                continue

            # 查找 I 开头的文件
            for f in os.listdir(sub_path):
                if f.startswith("I"):
                    src = os.path.join(sub_path, f)
                    dst = os.path.join(patient_path, f)
                    print(f"移动 {src} → {dst}")
                    shutil.move(src, dst)

            # 删除空的 Sxx 子文件夹（如果需要）
            try:
                shutil.rmtree(sub_path)
            except OSError:
                pass

def delete_file():
    root_dir = r"E:\dataset\MAT\终极任务\第二个队列完整椎体切片\第二个队列完整椎体切片"  # 修改为你的 MAT 根目录

    for patient in os.listdir(root_dir):
        patient_path = os.path.join(root_dir, patient)
        if not os.path.isdir(patient_path):
            continue

        for f in os.listdir(patient_path):
            if f.upper().startswith("DIRFILE"):  # 不区分大小写
                file_path = os.path.join(patient_path, f)
                try:
                    os.remove(file_path)
                    print(f"已删除: {file_path}")
                except Exception as e:
                    print(f"删除失败 {file_path}: {e}")



def organize_files(root_dir):
    """
    整理文件结构，移除中间层文件夹
    将每个子文件夹中的nrrd文件移动到其父目录，并删除空文件夹
    """
    # 遍历根目录下的所有文件夹（如A011-210330, A119-221021等）
    for folder in os.listdir(root_dir):
        folder_path = os.path.join(root_dir, folder)

        # 只处理目录，跳过文件
        if not os.path.isdir(folder_path):
            continue

        # 遍历每个文件夹下的子文件夹（如hel, zw等）
        for subfolder in os.listdir(folder_path):
            subfolder_path = os.path.join(folder_path, subfolder)

            # 只处理目录，跳过文件
            if not os.path.isdir(subfolder_path):
                continue

            # 遍历子文件夹中的所有nrrd文件
            for file in os.listdir(subfolder_path):
                if file.endswith('.nrrd'):
                    # 源文件路径
                    src = os.path.join(subfolder_path, file)
                    # 目标文件路径（移动到上一级目录）
                    dest = os.path.join(folder_path, file)

                    # 移动文件
                    if not os.path.exists(dest):  # 避免文件重名覆盖
                        shutil.move(src, dest)
                        print(f"移动文件: {src} -> {dest}")
                    else:
                        print(f"文件已存在，跳过: {dest}")

            # 检查子文件夹是否为空，如果为空则删除
            if not os.listdir(subfolder_path):
                os.rmdir(subfolder_path)
                print(f"删除空文件夹: {subfolder_path}")


def rename_file1():
    import re

    root = r"E:\dataset\MAT\classification\image_80"

    for patient in os.listdir(root):
        patient_path = os.path.join(root, patient)
        if not os.path.isdir(patient_path):
            continue

        # 遍历病人文件夹
        for file in os.listdir(patient_path):
            old_path = os.path.join(patient_path, file)

            if not os.path.isfile(old_path):
                continue

            # 匹配 slice 编号（结尾的数字部分）
            match = re.search(r"slice(\d+)\.png$", file)
            if match:
                num = int(match.group(1))
                new_num = f"{num:03d}"  # 格式化成三位数

                if "Segmentation" in file:  # mask 文件
                    new_name = f"{patient}_{new_num}_mask.png"
                else:  # 原始图像
                    new_name = f"{patient}_{new_num}.png"

                new_path = os.path.join(patient_path, new_name)

                print(f"重命名: {file} -> {new_name}")
                os.rename(old_path, new_path)


def move_file1():

    root = r"E:\dataset\MAT\classification\image_80"
    image_dir = os.path.join(root, "images")
    mask_dir = os.path.join(root, "masks")

    # 确保目标文件夹存在
    os.makedirs(image_dir, exist_ok=True)
    os.makedirs(mask_dir, exist_ok=True)

    # 遍历 Patient 文件夹
    for patient in os.listdir(root):
        patient_path = os.path.join(root, patient)
        if not os.path.isdir(patient_path) or patient in ["images", "masks"]:
            continue

        for file in os.listdir(patient_path):
            old_path = os.path.join(patient_path, file)
            if not os.path.isfile(old_path):
                continue

            if file.endswith("_mask.png"):
                new_path = os.path.join(mask_dir, file)
            elif file.endswith(".png"):
                new_path = os.path.join(image_dir, file)
            else:
                continue  # 忽略非 PNG 文件

            print(f"移动: {old_path} -> {new_path}")
            shutil.move(old_path, new_path)


def move_third_class():
    import cv2

    input_dir = r"E:\dataset\MAT\image_80\masks"  # 输入文件夹
    output_dir = r"E:\dataset\MAT\image_80\masks_1"  # 输出文件夹（避免覆盖原始文件）

    os.makedirs(output_dir, exist_ok=True)

    for file in os.listdir(input_dir):
        if not file.endswith(".png"):
            continue

        img_path = os.path.join(input_dir, file)

        # 以单通道方式读取
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

        # 将像素值 255 → 0
        img[img == 255] = 0
        img[img == 85] = 127
        img[img == 170] = 255

        out_path = os.path.join(output_dir, file)

        # 保存为单通道图像
        cv2.imwrite(out_path, img)

        print(f"处理完成: {file}")


def select_val():
    src_dir = r"E:\dataset\MAT\experiment_data\2_train\masks"  # 原始文件夹
    dst_dir = r"E:\dataset\MAT\experiment_data\2_val\masks"  # 目标文件夹

    os.makedirs(dst_dir, exist_ok=True)

    random.seed(42)
    # 获取所有图片
    all_files = [f for f in os.listdir(src_dir) if f.endswith(".png")]

    # 计算要移动的数量
    num_to_move = int(len(all_files) * 0.2)

    # 随机选择
    selected_files = random.sample(all_files, num_to_move)

    # 移动文件
    for f in selected_files:
        src_path = os.path.join(src_dir, f)
        dst_path = os.path.join(dst_dir, f)

        shutil.move(src_path, dst_path)
        print(f"移动: {f}")

    print(f"\n共移动 {len(selected_files)} 张图片到 {dst_dir}")


def rename_file2():
    root = r"E:\dataset\MAT\classification\N_T12"  # 你的T12文件夹路径
    for patient in os.listdir(root):
        patient_dir = os.path.join(root, patient)
        if not os.path.isdir(patient_dir):
            continue
        for file in os.listdir(patient_dir):
            src = os.path.join(patient_dir, file)
            dst = os.path.join(root, f"{patient}_{file}")
            shutil.move(src, dst)  # 如果想保留原文件，可改为 shutil.copy
            print(f"✅ {src} → {dst}")

        # 删除空文件夹
        os.rmdir(patient_dir)

    print("🎉 全部完成！")

def remove_file():
    # ===== 路径设置 =====
    src_dir = r"E:\dataset\MAT\classification\image_80\train\T12"  # 原始文件夹
    dst_dir = r"E:\dataset\MAT\classification\image_80\train\T12_val"  # 目标文件夹
    ratio = 0.2  # 移动比例（20%）

    os.makedirs(dst_dir, exist_ok=True)
    random.seed(42)

    # ===== 获取所有图片文件 =====
    all_files = [f for f in os.listdir(src_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    # ===== 随机选取 20% =====
    num_to_move = int(len(all_files) * ratio)
    selected_files = random.sample(all_files, num_to_move)

    # ===== 移动文件 =====
    for f in selected_files:
        src_path = os.path.join(src_dir, f)
        dst_path = os.path.join(dst_dir, f)
        shutil.move(src_path, dst_path)  # 如果想保留原文件，改成 shutil.copy
        print(f"✅ 移动: {f}")

    print(f"\n🎉 已移动 {num_to_move}/{len(all_files)} 张图片到 {dst_dir}")


def has_mask_no_mask():
    # 原始路径
    image_dir = r"E:\dataset\MAT\classification\image_80\images"  # 图片文件夹
    label_dir = r"E:\dataset\MAT\classification\image_80\masks"  # 标签文件夹

    # 目标路径
    has_label_dir = r"E:\dataset\MAT\classification\image_80\T12"
    no_label_dir = r"E:\dataset\MAT\classification\image_80\N_T12"

    # 创建目标文件夹
    os.makedirs(has_label_dir, exist_ok=True)
    os.makedirs(no_label_dir, exist_ok=True)

    # 遍历所有图片
    for img_name in os.listdir(image_dir):
        if not img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            continue

        img_path = os.path.join(image_dir, img_name)
        base_name = os.path.splitext(img_name)[0]  # 去掉扩展名
        mask_name = base_name + "_mask.png"
        mask_path = os.path.join(label_dir, mask_name)

        # 判断标签是否存在
        if os.path.exists(mask_path):
            shutil.move(img_path, os.path.join(has_label_dir, img_name))
        else:
            shutil.move(img_path, os.path.join(no_label_dir, img_name))

    print("✅ 分类完成：")
    print(f"带标签的图片已移动到 {has_label_dir}/")
    print(f"无标签的图片已移动到 {no_label_dir}/")


# 去除两边手臂
def move_arm():
    import cv2
    import numpy as np

    # 读灰度图（路径改成你的文件）
    mask = cv2.imread("data/A275/I430.png", cv2.IMREAD_GRAYSCALE)

    # 将所有非零像素视为前景（0保留为背景）
    binary = (mask > 0).astype(np.uint8) * 255

    # 连通域标记（8连通）
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary, connectivity=8)

    if num_labels <= 1:
        # 没有前景，直接保存原图或保持不变
        cv2.imwrite("mask_kept.png", mask)
    else:
        # 找出面积最大的连通域（排除背景标签0）
        areas = stats[1:, cv2.CC_STAT_AREA]
        largest_idx = 1 + np.argmax(areas)  # +1 因为 stats 从标签1开始

        # 创建输出：默认全部设为0
        out = np.zeros_like(mask)

        # 将属于最大连通域的像素保留原始值（127或255）
        mask_largest = (labels == largest_idx)
        out[mask_largest] = mask[mask_largest]

        cv2.imwrite("data/I430.png", out)
        print("已保存 （仅保留最大连通域，保留原像素值）")


def keep_largest_regions(mask):
    """
    对 mask 中的 127 和 225 像素值，各自只保留最大连通区域，其余置 0
    """
    result = np.zeros_like(mask)
    for val in [127, 255]:
        # 二值化：目标像素为1，其余为0
        binary = (mask == val).astype(np.uint8)

        # 连通区域标记
        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)

        if num_labels <= 1:
            continue  # 没有连通区域

        # 找到最大连通区域（排除背景0）
        largest_label = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])

        # 只保留最大区域
        result[labels == largest_label] = val

    return result












if __name__ == "__main__":
    # rename_file1()
    # move_file1()
    # move_third_class()
    # move_arm()

    mask = cv2.imread('data/H51/I4700000.png', cv2.IMREAD_GRAYSCALE)
    processed_mask = keep_largest_regions(mask)
    cv2.imwrite('data/H51_1/I4700000.png', processed_mask)

    # has_mask_no_mask()

    # select_val()

    # # 请将此处替换为你的MAT文件夹的实际路径   删除中间的目录
    # mat_directory = r"E:\dataset\MAT\单层切片50人"
    # # 验证路径是否存在
    # if not os.path.exists(mat_directory):
    #     print(f"错误: 路径 '{mat_directory}' 不存在")
    # else:
    #     print(f"开始整理文件夹: {mat_directory}")
    #     organize_files(mat_directory)
    #     print("整理完成!")


    # rename_file()


    # input_file = r"E:\dataset\MAT\MAT\trainIMAT\HE^JIZHANG (P003385855)\Thorax^1_ThoraxRoutine (Adult) (20230311)\Segmentation_1.seg.nrrd"  # 输入文件路径
    # output_dir = "data/sge_output_pngs_masks"   # 输出目录
    # nrrd_to_png(input_file, output_dir)

    # # nrrd 转换
    # input_root = r"E:\dataset\MAT\单层切片50人"        # nrrd 数据根目录
    # output_root = r"E:\dataset\MAT\单层切片50人_png"   # 保存 PNG 的目录
    # process_all_nrrd(input_root, output_root)

    # # read_dicom()
    # input_root = r"E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片"       # dicom 数据根目录
    # output_root = r"E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片_png"   # 保存 PNG 的目录
    # process_all_dicom(input_root, output_root)

    # move_file()
    # delete_file()

    # rename_file2()
    # remove_file()

    # root_dir = r"E:\dataset\MAT\终极任务\第一个队列完整椎体切片\全部需分割体积的无标签"  # 换成你的根目录路径
    # for root, dirs, files in os.walk(root_dir):
    #     for file in files:
    #         if file.endswith(".dcm"):
    #             print(os.path.join(root, file))

    pass

"""


MAT
    A011-210330
        DIRFILE
        I570
    A119-221021
        DIRFILE
        I530
    ...

MAT
    A011-210330
        hel
            I570.nrrd
            I670.nrrd
    A119-221021
        zw
            I530.nrrd
            I670.nrrd
    ...

MAT
    Patient001
        I150.png
        I160.png
    Patient002
        I150.png
        I160.png
        ...
    ...

MAT
    Patient001
        Patient001_000.png
        Patient001_001.png
        ...
        Patient001_000_mask.png
        Patient001_001_mask.png
        ...
    Patient002
        Patient002_007.png
        Patient002_008.png
        ...
        Patient002_007_mask.png
        Patient002_008_mask.png
        ...
    ...


T12
    A001
        I5400000
        I5400001.dcm
    A002
        I5400000
        I5400001.dcm
    ...



T12
    A001_I5400000.png
    A002_I5100000.png
    ...

"""