import csv
import datetime
import os
import time

import numpy as np
import torch.optim as optim
import torch
import torch.nn as nn
from PIL import Image
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import albumentations as A
from dataset import SegDataset
from unetpp2 import NestedUNet
from model_segformer import SegFormer
from model_mask2former import Mask2Former
from utils import vis_valualization
os.environ["ALBUMENTATIONS_DISABLE_VERSION_CHECK"] = "1"   # 禁用版本检查

# --------------------------------------
# 评估指标
# --------------------------------------
# def compute_metrics(pred, target, smooth=1e-6):
#     pred = torch.argmax(pred, dim=1)  # [B, H, W]
#     intersection = (pred * target).sum()
#     union = pred.sum() + target.sum() - intersection
#     dice = (2 * intersection + smooth) / (pred.sum() + target.sum() + smooth)
#     iou = (intersection + smooth) / (union + smooth)
#     return dice.item(), iou.item()


def compute_metrics(pred, target, num_classes=3, smooth=1e-6):
    """
    pred: [B, C, H, W]，模型输出
    target: [B, H, W]，真实标签，取值 0~num_classes-1
    """
    pred = torch.argmax(pred, dim=1)  # [B, H, W]
    dice_list = []
    iou_list = []

    for cls in range(1, num_classes):   # 忽略背景类 0
        pred_cls = (pred == cls).float()
        target_cls = (target == cls).float()

        intersection = (pred_cls * target_cls).sum()
        union = pred_cls.sum() + target_cls.sum() - intersection

        dice = (2 * intersection + smooth) / (pred_cls.sum() + target_cls.sum() + smooth)
        iou = (intersection + smooth) / (union + smooth)

        dice_list.append(dice.item())
        iou_list.append(iou.item())

    return dice_list, iou_list




# --------------------------------------
# Dice 损失
# --------------------------------------
# def dice_loss(pred, target, smooth=1e-6):
#     pred = torch.softmax(pred, dim=1)  # [B, C, H, W]
#     pred = pred[:, 1, :, :]  # 前景概率，[B, H, W]
#     target = target.float()  # [B, H, W]
#     intersection = (pred * target).sum(dim=(1, 2))
#     pred_sum = pred.sum(dim=(1, 2))
#     target_sum = target.sum(dim=(1, 2))
#     dice = (2 * intersection + smooth) / (pred_sum + target_sum + smooth)
#     return (1 - dice).mean()

def dice_loss(pred, target, num_classes=3, smooth=1e-6):
    """
    pred: [B, C, H, W]，未softmax或已softmax都可
    target: [B, H, W]，值为 0~(num_classes-1)
    """
    pred = torch.softmax(pred, dim=1)  # [B, C, H, W]
    target_onehot = torch.nn.functional.one_hot(target, num_classes).permute(0, 3, 1, 2).float()  # [B, C, H, W]

    dice = []
    for c in range(1, num_classes):
        pred_c = pred[:, c]
        target_c = target_onehot[:, c]
        intersection = (pred_c * target_c).sum(dim=(1, 2))
        union = pred_c.sum(dim=(1, 2)) + target_c.sum(dim=(1, 2))
        dice_c = (2 * intersection + smooth) / (union + smooth)
        dice.append(dice_c)

    # 返回每个样本每类 dice 的平均，然后再取 batch 平均
    dice = torch.stack(dice, dim=1)  # [B, C]
    return 1 - dice.mean()

# --------------------------------------
# 训练和评估
# --------------------------------------
def train_model(model, train_loader, val_loader, optimizer, scheduler, num_epochs, csv_path, model_path, vis_path, device='cuda'):
    model = model.to(device)
    criterion = nn.CrossEntropyLoss()

    # 记录训练和验证损失、Dice 和 IoU
    train_losses = []
    train_dices = []
    train_ious = []
    val_losses = []
    val_dices = []
    val_ious = []

    best_dice = 0.0
    patience = 20
    counter = 0
    for epoch in range(num_epochs):
        # 记录训练开始时间
        train_start_time = time.time()

        model.train()
        train_loss = 0.0
        train_dice = [0.0, 0.0]  # 对应前景类 1 和 2
        train_iou = [0.0, 0.0]
        for images, labels in tqdm(train_loader, desc=f'训练 Epoch {epoch + 1}/{num_epochs}'):
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(images)

            ## 损失函数计算 TODO
            ce_loss = criterion(outputs, labels)
            dice_loss_value = dice_loss(outputs, labels)
            loss = ce_loss + dice_loss_value

            loss.backward()
            optimizer.step()
            scheduler.step()

            train_loss += loss.item()
            dice_list, iou_list = compute_metrics(outputs, labels)
            for c in range(1, 3):  # 类别1和2
                train_dice[c - 1] += dice_list[c - 1]
                train_iou[c - 1] += iou_list[c - 1]

        train_loss /= len(train_loader)

        train_dice_class1 = train_dice[0] / len(train_loader)
        train_dice_class2 = train_dice[1] / len(train_loader)
        train_iou_class1 = train_iou[0] / len(train_loader)
        train_iou_class2 = train_iou[1] / len(train_loader)

        # 计算训练耗时
        train_time = time.time() - train_start_time
        train_minutes = int(train_time // 60)
        train_seconds = int(train_time % 60)

        # 记录验证开始时间
        val_start_time = time.time()

        # 验证
        model.eval()
        val_loss = 0.0
        val_dice = [0.0, 0.0]
        val_iou = [0.0, 0.0]
        with torch.no_grad():
            for images, labels in tqdm(val_loader, desc=f'验证 Epoch {epoch + 1}/{num_epochs}'):
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)

                # 计算验证损失（交叉熵 + Dice）
                ce_loss = criterion(outputs, labels)
                dice_loss_value = dice_loss(outputs, labels)
                loss = ce_loss + dice_loss_value

                val_loss += loss.item()
                dice_list, iou_list = compute_metrics(outputs, labels)
                for c in range(1, 3):  # 类别1和2
                    val_dice[c - 1] += dice_list[c - 1]
                    val_iou[c - 1] += iou_list[c - 1]

        val_loss /= len(val_loader)


        val_dice_class1 = val_dice[0] / len(val_loader)
        val_dice_class2 = val_dice[1] / len(val_loader)
        val_iou_class1 = val_iou[0] / len(val_loader)
        val_iou_class2 = val_iou[1] / len(val_loader)

        # 计算验证耗时
        val_time = time.time() - val_start_time
        val_minutes = int(val_time // 60)
        val_seconds = int(val_time % 60)

        # 打印结果，包括训练和验证时间
        print(f'Epoch {epoch + 1}/{num_epochs}:')
        print(f'训练 Loss: {train_loss:.4f}, '
              f'Class1_Dice: {train_dice_class1:.4f}, '
              f'Class2_Dice: {train_dice_class2:.4f}, '
              f'Class1_IoU: {train_iou_class1:.4f}, '
              f'Class2_IoU: {train_iou_class2:.4f}, '
              f'时间: {train_minutes}m {train_seconds}s')
        print(f'验证 Loss: {val_loss:.4f}, '
              f'Class1_Dice: {val_dice_class1:.4f}, '
              f'Class2_Dice: {val_dice_class2:.4f}, '
              f'Class1_IoU: {val_iou_class1:.4f}, '
              f'Class2_IoU: {val_iou_class2:.4f}, '
              f'时间: {val_minutes}m {val_seconds}s')


        if epoch + 1 == 20 or epoch + 1 == 30 or epoch + 1 == 40 or epoch + 1 == 50:
            torch.save(model.state_dict(), f'checkpoints/best_model_mask2former_end_{epoch + 1}.pth')  #
            print('保存最佳模型！')


        # 保存最佳模型
        val_dice_mean = (val_dice_class1 + val_dice_class2) / 2
        if val_dice_mean > best_dice:
            best_dice = val_dice_mean
            # best_model_unet_.pth：没有数据增强，没有学习率衰减，使用Adam优化器     best_model_unet_222.pth：数据增强，有学习率衰减，使用AdamW优化器，nn.Dropout2d(0.3)
            torch.save(model.state_dict(), model_path)  #
            print('保存最佳模型！')
            counter = 0
        else:
            counter += 1

        # 记录训练和验证损失、Dice 和 IoU
        train_losses.append(train_loss)
        val_losses.append(val_loss)
        train_dices.append((train_dice_class1 + train_dice_class2) / 2)
        train_ious.append((train_iou_class1 + train_iou_class2) / 2)
        val_dices.append((val_dice_class1 + val_dice_class2) / 2)
        val_ious.append((val_iou_class1 + val_iou_class2) / 2)

        if counter >= patience:
            print("Early stopping")
            break

    # 可视化训练和验证损失、Dice 和 IoU
    vis_valualization(train_losses, train_dices, train_ious, val_losses, val_dices, val_ious, save_path=vis_path)





def train_unet():
    batch_size = 1
    num_epochs = 50
    lr = 1e-4

    csv_path = 'visualization/unetpp_metrics.csv'
    vis_path = 'visualization/unetpp_metrics.png'
    model_path = 'checkpoints/best_model_unetpp.pth'

    train_transform = A.Compose([
        A.HorizontalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1, rotate_limit=15, p=0.5),
        A.RandomBrightnessContrast(p=0.3),
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 仍然对 numpy 做标准化
    ])
    val_transform = A.Compose([
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 仍然对 numpy 做标准化
    ])

    root_dir = r"E:\dataset\MAT\experiment_data"
    # 创建数据集
    train_dataset = SegDataset(root_dir=root_dir, split='train', transform=train_transform)   # 42
    val_dataset = SegDataset(root_dir=root_dir, split='val', transform=val_transform)  # 42

    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=8)

    model = NestedUNet(num_classes = 3, input_channels=3)

    total_steps = num_epochs * len(train_dataset) // batch_size
    optimizer = optim.AdamW(model.parameters(), lr=lr, betas=[0.9, 0.999], weight_decay=0.05)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_steps, eta_min=5e-6)

    # 训练模型
    train_model(model, train_loader, val_loader, optimizer, scheduler, num_epochs, csv_path, model_path, vis_path, device='cuda')


def train_SegFormer():
    batch_size = 1
    num_epochs = 50
    lr = 1e-4

    csv_path = 'visualization/SegFormer_metrics.csv'
    vis_path = 'visualization/SegFormer_metrics.png'
    model_path = 'checkpoints/best_model_SegFormer.pth'


    train_transform = A.Compose([
        A.HorizontalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1, rotate_limit=15, p=0.5),
        A.RandomBrightnessContrast(p=0.3),
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 仍然对 numpy 做标准化
    ])
    val_transform = A.Compose([
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 仍然对 numpy 做标准化
    ])

    root_dir = r"E:\dataset\MAT\experiment_data"
    # 创建数据集
    train_dataset = SegDataset(root_dir=root_dir, split='train', transform=train_transform)   # 42
    val_dataset = SegDataset(root_dir=root_dir, split='val', transform=val_transform)  # 42

    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=8)

    model = SegFormer(n_channels=3, n_classes=3)

    total_steps = num_epochs * len(train_dataset) // batch_size
    optimizer = optim.AdamW(model.parameters(), lr=lr, betas=[0.9, 0.999], weight_decay=0.05)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_steps, eta_min=5e-6)

    # 训练模型
    train_model(model, train_loader, val_loader, optimizer, scheduler, num_epochs, csv_path, model_path, vis_path, device='cuda')


def train_mask2former():
    batch_size = 1
    num_epochs = 50
    lr = 1e-4

    csv_path = 'visualization/mask2former_metrics.csv'
    vis_path = 'visualization/mask2former_metrics.png'
    model_path = 'checkpoints/best_model_mask2former.pth'

    csv_path = 'visualization/mask2former_metrics_end.csv'
    vis_path = 'visualization/mask2former_metrics_end.png'
    model_path = 'checkpoints/best_model_mask2former_end.pth'



    train_transform = A.Compose([
        A.HorizontalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1, rotate_limit=15, p=0.5),
        A.RandomBrightnessContrast(p=0.3),
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 仍然对 numpy 做标准化
    ])
    val_transform = A.Compose([
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 仍然对 numpy 做标准化
    ])

    root_dir = r"E:\dataset\MAT\experiment_data"
    # root_dir = r"E:\dataset\MAT\all_label_246"
    # 创建数据集
    train_dataset = SegDataset(root_dir=root_dir, split='train', transform=train_transform)   # 42
    val_dataset = SegDataset(root_dir=root_dir, split='val', transform=val_transform)  # 42

    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=8)

    model = Mask2Former(n_channels=3, n_classes=3)

    # total_steps = num_epochs * len(train_dataset) // batch_size
    # optimizer = optim.AdamW(model.parameters(), lr=lr, betas=[0.9, 0.999], weight_decay=0.05)
    # scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_steps, eta_min=5e-6)


    total_steps = num_epochs * len(train_dataset) // batch_size
    optimizer = optim.AdamW(model.parameters(), lr=lr, betas=[0.9, 0.999], weight_decay=0.05)
    scheduler = optim.lr_scheduler.StepLR(
        optimizer,
        step_size=2500,  # 衰减间隔（每多少步衰减一次）  每10个epoch衰减一次
        gamma=0.5  # 衰减系数（学习率 = 学习率 * gamma）
    )

    # 训练模型
    train_model(model, train_loader, val_loader, optimizer, scheduler, num_epochs, csv_path, model_path, vis_path, device='cuda')



if __name__ == '__main__':



    print("========================================mask2former=============================================================")
    start_time = time.time()
    train_mask2former()
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print(f"total time {total_time_str}")


    # print("========================================SegFormer=============================================================")
    # start_time = time.time()
    # train_SegFormer()
    # total_time = time.time() - start_time
    # total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    # print(f"total time {total_time_str}")
    #
    # print("========================================Unet=============================================================")
    # start_time = time.time()
    # train_unet()
    # total_time = time.time() - start_time
    # total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    # print(f"total time {total_time_str}")







"""
data
    images
        Patient-A001
            Patient-A001-0001.png
            Patient-A001-0002.png
            ...
        Patient-A002
            Patient-A002-0001.png
            Patient-A002-0002.png
            ...
    labels
            Patient-A060
            Patient-A060-0001.png
            Patient-A060-0002.png
            ...
        Patient-A061
            Patient-A061-0001.png
            Patient-A061-0002.png
            ...

data
    train
    
"""