import matplotlib.pyplot as plt


def vis_valualization(train_losses, train_dices, train_ious, val_losses, val_dices, val_ious, save_path):
    # train_losses = [...]
    # train_dices = [...]
    # train_ious = [...]
    # val_losses = [...]
    # val_dices = [...]
    # val_ious = [...]

    epochs = list(range(1, len(train_losses) + 1))

    # 创建图
    plt.figure(figsize=(18, 5))

    # 1. Loss
    plt.subplot(1, 3, 1)
    plt.plot(epochs, train_losses, label='Train Loss', marker='o')
    plt.plot(epochs, val_losses, label='Val Loss', marker='s')
    plt.title('Loss over Epochs')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True)
    plt.legend()

    # 2. Dice
    plt.subplot(1, 3, 2)
    plt.plot(epochs, train_dices, label='Train Dice', marker='o')
    plt.plot(epochs, val_dices, label='Val Dice', marker='s')
    plt.title('Dice Score over Epochs')
    plt.xlabel('Epoch')
    plt.ylabel('Dice')
    plt.grid(True)
    plt.legend()

    # 3. IoU
    plt.subplot(1, 3, 3)
    plt.plot(epochs, train_ious, label='Train IoU', marker='o')
    plt.plot(epochs, val_ious, label='Val IoU', marker='s')
    plt.title('IoU over Epochs')
    plt.xlabel('Epoch')
    plt.ylabel('IoU')
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.savefig(save_path, dpi=300)  # 保存为高清图像
    plt.show()


def move_file():
    import os
    import shutil

    # 设置源文件夹和目标文件夹路径
    source_dir = r"E:\code\python\data_handle\Unet\data2\test\masks"  # 替换为你的原始路径
    target_dir = r"E:\code\python\data_handle\Unet\data2\test\masks222"  # 替换为你的目标路径

    # 如果目标文件夹不存在，创建它
    os.makedirs(target_dir, exist_ok=True)

    # 支持的图像扩展名
    img_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff']

    # 获取所有图像文件并排序（可按名称排序）
    all_images = sorted([
        f for f in os.listdir(source_dir)
        if os.path.splitext(f)[1].lower() in img_extensions
    ])

    # 每隔一张移动一张（即 index 为偶数时移动）
    for idx, filename in enumerate(all_images):
        if idx % 5 == 0:
            src_path = os.path.join(source_dir, filename)
            dst_path = os.path.join(target_dir, filename)
            shutil.move(src_path, dst_path)
            print(f"Moved: {filename}")

    print("✅ 图片移动完成。")


if __name__ == '__main__':
    move_file()