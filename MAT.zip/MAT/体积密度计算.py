import os
import numpy as np
from PIL import Image
import csv
import pydicom

def count_mask_nonzero_pixels(mask_dir, output_csv):
    """
    统计指定mask目录下各患者子文件夹中所有图像的非零像素总数，并输出到CSV文件

    :param mask_dir: mask根目录路径（结构应为：mask_dir/患者编号/图像文件.png）
    :param output_csv: 结果保存的CSV文件路径（如"统计结果.csv"）
    """
    # 新增：初始化结果列表用于保存CSV数据
    results = []
    results.append(["患者ID", "非零像素总数"])  # CSV表头

    # 遍历mask目录下的所有患者子文件夹（一级子目录）
    for patient_id in os.listdir(mask_dir):
        patient_dir = os.path.join(mask_dir, patient_id)

        # 跳过非目录项和空目录
        if not os.path.isdir(patient_dir) or not os.listdir(patient_dir):
            continue

        total_nonzero = 0  # 患者总非零像素计数器

        # 遍历患者文件夹内的所有文件
        for img_file in os.listdir(patient_dir):
            # 仅处理PNG图像
            if not img_file.lower().endswith('.png'):
                continue

            img_path = os.path.join(patient_dir, img_file)

            try:
                # 读取图像并转换为numpy数组（保持原始像素值）
                img = Image.open(img_path)
                pixel_array = np.array(img)

                # 统计当前图像的非零像素数并累加
                nonzero_count = np.count_nonzero(pixel_array)
                total_nonzero += nonzero_count

            except Exception as e:
                print(f"警告：处理文件 {img_path} 时出错: {str(e)}，已跳过")
                continue

        # 构造结果行并添加到列表（保持原有打印逻辑）
        result_row = [patient_id, total_nonzero]
        results.append(result_row)

        # 保持原有输出逻辑
        if total_nonzero > 0:
            print(f"患者 [{patient_id}] 非零像素总数: {total_nonzero}")
        else:
            print(f"患者 [{patient_id}] 无有效非零像素或无有效图像")

    # 新增：将结果写入CSV文件（包含异常处理）
    try:
        with open(output_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(results)
        print(f"统计结果已保存至：{output_csv}")
    except Exception as e:
        print(f"警告：CSV文件写入失败: {str(e)}")


def is_dicom_file(file_path):
    try:
        with open(file_path, 'rb') as f:
            f.seek(128)  # 跳过DICOM文件前128字节预amble
            return f.read(4) == b'DICM'  # 检查是否存在DICM标识
    except:
        return False


def extract_slice_spacing_from_csv(csv_path, mr_dir, output_csv):
    """
    根据CSV中的患者ID，读取MR文件夹对应患者的DICOM文件，提取PixelSpacing并写入新CSV列

    :param csv_path: 输入患者ID的CSV文件路径（需包含"患者ID"列）
    :param mr_dir: MR根目录路径（结构：mr_dir/患者ID/[次级序列文件夹]/无扩展名DICOM 或 mr_dir/患者ID/*.dcm）
    :param output_csv: 结果保存的CSV文件路径（包含新增"PixelSpacing"列）
    """
    # 读取原始CSV数据
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        original_data = list(reader)
        # 检查是否有"患者ID"列
        if '患者ID' not in reader.fieldnames:
            raise ValueError("输入CSV文件需包含'患者ID'列")

    # 新增结果列
    new_fieldnames = reader.fieldnames + ['PixelSpacing']
    results = []

    for row in original_data:
        patient_id = row['患者ID']
        patient_dir = os.path.join(mr_dir, patient_id)
        slice_spacing = None  # 初始化PixelSpacing为None

        # 步骤1：检查患者文件夹是否存在
        if not os.path.isdir(patient_dir):
            print(f"警告：患者 [{patient_id}] 文件夹 {patient_dir} 不存在，跳过")
            results.append({**row, 'PixelSpacing': '文件夹不存在'})
            continue

        dicom_files = [os.path.join(patient_dir, f) for f in os.listdir(patient_dir)]
        # 取第三个文件（索引2）
        if len(dicom_files) >= 3:
            dicom_path = dicom_files[2]
        else:
            slice_spacing = f"无次级目录且当前目录无足够.dcm文件（需3个，当前{len(dicom_files)}个）"
            results.append({**row, 'PixelSpacing': slice_spacing})
            continue

        # 读取DICOM文件并提取PixelSpacing
        try:
            ds = pydicom.dcmread(dicom_path)
            PixelSpacing = ds.get('PixelSpacing', '未找到该标签')
        except Exception as e:
            PixelSpacing = f"读取DICOM文件失败: {str(e)}"

        # 构造结果行
        results.append({**row, 'PixelSpacing': PixelSpacing[0]})
        print(f"患者 [{patient_id}] PixelSpacing: {PixelSpacing[0]}")

    # 写入新CSV文件
    with open(output_csv, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=new_fieldnames)
        writer.writeheader()
        writer.writerows(results)
    print(f"PixelSpacing已写入：{output_csv}")


def calculate_patient_hu_mean(ct_dir, mask_dir, output_csv):
    """
    按患者计算mask非零区域对应的CT DICOM文件平均HU值（支持无序列子目录场景）
    """
    results = [["患者ID", "平均HU值"]]

    # 遍历mask中的所有患者子文件夹（一级目录）
    for patient_id in os.listdir(mask_dir):
        patient_mask_dir = os.path.join(mask_dir, patient_id)
        patient_ct_dir = os.path.join(ct_dir, patient_id)

        # 跳过非目录或CT患者目录不存在的情况
        if not os.path.isdir(patient_mask_dir) or not os.path.isdir(patient_ct_dir):
            results.append([patient_id, "患者目录缺失"])
            print(f"警告：患者 [{patient_id}] 目录不完整，跳过")
            continue

        # 检查患者目录本身是否有DICOM文件
        ct_files_in_patient_dir = [f for f in os.listdir(patient_ct_dir) if is_dicom_file(os.path.join(patient_ct_dir, f))]
        if not ct_files_in_patient_dir:
            results.append([patient_id, "无序列子目录且无DICOM文件"])
            print(f"警告：患者 [{patient_id}] CT目录无序列子目录且无DICOM文件，跳过")
            continue
        target_series_dir = patient_ct_dir  # 直接使用患者目录

        # 步骤2：收集mask患者子文件夹中的PNG文件
        mask_files = [f for f in os.listdir(patient_mask_dir)
                      if f.lower().endswith('.png')]
        if not mask_files:
            results.append([patient_id, "无mask文件"])
            print(f"警告：患者 [{patient_id}] mask目录无PNG文件，跳过")
            continue

        # 步骤3：收集目标目录中的DICOM文件（按base_name匹配）
        ct_dicom_files = {}
        for dcm_file in os.listdir(target_series_dir):
            dcm_path = os.path.join(target_series_dir, dcm_file)
            if is_dicom_file(dcm_path):
                base_name = os.path.splitext(dcm_file)[0]
                # print(base_name)
                ct_dicom_files[base_name] = dcm_path

        # 步骤4：逐文件匹配并计算HU均值（与原逻辑一致）
        total_hu_sum = 0.0
        total_pixels = 0
        for mask_file in mask_files:
            mask_base = os.path.splitext(mask_file)[0]
            ######
            dcm_path = ct_dicom_files.get(mask_base)
            ######
            if not dcm_path:
                print(f"提示：患者 [{patient_id}] mask文件 {mask_file} 无对应DICOM文件，跳过")
                continue

            # 读取mask并提取非零区域（与原逻辑一致）
            try:
                mask_img = Image.open(os.path.join(patient_mask_dir, mask_file))
                mask_array = np.array(mask_img)
                non_zero_coords = np.nonzero(mask_array)
                current_pixels = len(non_zero_coords[0])
                if current_pixels == 0:
                    print(f"提示：患者 [{patient_id}] mask文件 {mask_file} 无有效非零区域，跳过")
                    continue
            except Exception as e:
                print(f"警告：患者 [{patient_id}] 处理mask文件 {mask_file} 出错: {str(e)}，跳过")
                continue

            # 读取DICOM并计算HU值（与原逻辑一致）
            try:
                ds = pydicom.dcmread(dcm_path)
                slope = ds.RescaleSlope
                intercept = ds.RescaleIntercept

                hu_array = ds.pixel_array.astype(np.float64) * slope + intercept

            except Exception as e:
                print(f"警告：患者 [{patient_id}] 处理DICOM文件 {dcm_path} 出错: {str(e)}，跳过")
                continue

            # 累加区域HU值和像素数（与原逻辑一致）
            try:
                region_hu = hu_array[non_zero_coords]
                total_hu_sum += np.sum(region_hu)
                total_pixels += current_pixels
            except Exception as e:
                print(f"警告：患者 [{patient_id}] 提取区域HU值出错: {str(e)}，跳过")
                continue

        # 计算患者级平均HU值（与原逻辑一致）
        if total_pixels > 0:
            patient_avg = total_hu_sum / total_pixels
            results.append([patient_id, f"{patient_avg:.2f}"])
            print(f"患者 [{patient_id}] 平均HU值: {patient_avg:.2f}（总像素数: {total_pixels}）")
        else:
            results.append([patient_id, "无有效数据"])
            print(f"患者 [{patient_id}] 无有效非零区域或计算失败")

    # 写入CSV文件（与原逻辑一致）
    try:
        with open(output_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(results)
        print(f"患者级HU均值统计结果已保存至：{output_csv}")
    except Exception as e:
        print(f"警告：CSV写入失败: {str(e)}")

def count_mask_png_count(mask_dir, output_csv):
    """
    统计指定mask目录下各患者子文件夹中PNG文件的数量，并输出到CSV文件

    :param mask_dir: mask根目录路径（结构应为：mask_dir/患者编号/图像文件.png）
    :param output_csv: 结果保存的CSV文件路径（如"PNG数量统计.csv"）
    """
    # 初始化结果列表（表头为患者ID和PNG数量）
    results = []
    results.append(["患者ID", "PNG文件数量"])

    # 遍历mask目录下的所有患者子文件夹（一级子目录）
    for patient_id in os.listdir(mask_dir):
        patient_dir = os.path.join(mask_dir, patient_id)

        # 跳过非目录项和空目录
        if not os.path.isdir(patient_dir) or not os.listdir(patient_dir):
            continue

        # 统计当前患者子文件夹中的PNG文件数量
        png_files = [f for f in os.listdir(patient_dir) if f.lower().endswith('.png')]
        png_count = len(png_files)

        # 构造结果行并添加到列表
        result_row = [patient_id, png_count]
        results.append(result_row)

        # 输出到控制台
        print(f"患者 [{patient_id}] PNG文件数量: {png_count}")

    # 将结果写入CSV文件（包含异常处理）
    try:
        with open(output_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(results)
        print(f"PNG文件数量统计结果已保存至：{output_csv}")
    except Exception as e:
        print(f"警告：CSV文件写入失败: {str(e)}")





if __name__ == '__main__':

    # count_mask_nonzero_pixels(r"E:\dataset\MAT\终极任务\计算HU值数据\第一个队列完整椎体切片_png_pred", "非零像素统计结果-train.csv")

    # extract_slice_spacing_from_csv(
    #     csv_path="非零像素统计结果-train.csv",  # 输入CSV（包含患者ID）
    #     mr_dir=r"E:\dataset\MAT\终极任务\第一个队列完整椎体切片\第一个队列完整椎体切片",  # DICON文件夹路径
    #     output_csv="带PixelSpacing的统计结果-train.csv"  # 输出CSV路径
    # )

    # count_mask_png_count(r"E:\dataset\MAT\终极任务\第一个队列完整椎体切片\第一个队列完整椎体切片_png_pred", "mask_PNG数量统计-train.csv")

    calculate_patient_hu_mean(
        ct_dir="E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片_dcm",          # CT DICOM文件夹路径
        mask_dir="E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片_png_mask",  # mask PNG文件夹路径
        output_csv="E:\dataset\MAT\终极任务\第二个队列单层切片\CT区域HU均值统计-train.csv"         # 输出文件路径
    )


"""
MAT
    A001
        I50000
        I60000
        ...
    A002
        I50000.dcm
        I60000.dcm
        ...
    ...
"""