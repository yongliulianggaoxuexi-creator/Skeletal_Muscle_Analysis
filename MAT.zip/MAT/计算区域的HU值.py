import os
import csv
import numpy as np
from PIL import Image
import pydicom

def is_dicom_file(path):
    try:
        pydicom.dcmread(path, stop_before_pixels=True)
        return True
    except Exception:
        return False

def build_dicom_index_recursive(patient_ct_dir):
    ct_index = {}
    for root, _, files in os.walk(patient_ct_dir):
        for f in files:
            full = os.path.join(root, f)
            if is_dicom_file(full):
                base = os.path.splitext(f)[0]
                ct_index[base] = full
    return ct_index

def calculate_label_regions_hu(ct_dir, mask_dir, output_csv, labels=(127, 255)):
    """
    对每个患者每个 mask PNG 文件，分别把 labels 中的像素视为一个整体区域，
    计算该区域对应的平均 HU 并写入 CSV。
    """
    rows = [["患者ID", "mask文件", "label", "pixels", "mean_hu"]]

    for patient_id in sorted(os.listdir(mask_dir)):
        patient_mask_dir = os.path.join(mask_dir, patient_id)
        patient_ct_dir = os.path.join(ct_dir, patient_id)

        if not os.path.isdir(patient_mask_dir):
            print(f"警告：mask目录中患者[{patient_id}]不是目录，跳过。")
            continue
        if not os.path.isdir(patient_ct_dir):
            print(f"警告：CT目录中患者[{patient_id}]不存在，跳过。")
            continue

        ct_index = build_dicom_index_recursive(patient_ct_dir)
        if not ct_index:
            print(f"警告：患者 [{patient_id}] 未发现 DICOM 文件，跳过。")
            continue

        mask_files = [f for f in os.listdir(patient_mask_dir) if f.lower().endswith('.png')]
        if not mask_files:
            print(f"警告：患者 [{patient_id}] 无 mask PNG 文件，跳过。")
            continue

        for mask_file in sorted(mask_files):
            mask_path = os.path.join(patient_mask_dir, mask_file)
            mask_base = os.path.splitext(mask_file)[0]

            dcm_path = ct_index.get(mask_base)
            if not dcm_path:
                print(f"提示：患者 [{patient_id}] mask {mask_file} 未找到对应 DICOM (basename={mask_base})，跳过此mask。")
                continue

            # 读取 mask
            try:
                mask_img = Image.open(mask_path).convert('L')
                mask_arr = np.array(mask_img)
            except Exception as e:
                print(f"警告：读取 mask {mask_path} 出错: {e}，跳过。")
                continue

            # 读取 DICOM HU 数组
            try:
                ds = pydicom.dcmread(dcm_path)
                slope = float(getattr(ds, 'RescaleSlope', 1.0))
                intercept = float(getattr(ds, 'RescaleIntercept', 0.0))
                hu_array = ds.pixel_array.astype(np.float64) * slope + intercept
            except Exception as e:
                print(f"警告：读取 DICOM {dcm_path} 出错: {e}，跳过。")
                continue

            for lbl in labels:
                mask_bool = (mask_arr == lbl)
                pixels = int(np.count_nonzero(mask_bool))
                if pixels == 0:
                    print(f"提示：患者[{patient_id}] 文件 {mask_file} 中无标签 {lbl} 像素。")
                    rows.append([patient_id, mask_file, lbl, 0, "NaN", dcm_path])
                    continue

                try:
                    region_hu = hu_array[mask_bool]
                    mean_hu = float(np.mean(region_hu)) if region_hu.size > 0 else float('nan')
                except Exception as e:
                    print(f"警告：计算 HU 失败 patient={patient_id}, file={mask_file}, label={lbl}: {e}")
                    mean_hu = float('nan')

                rows.append([patient_id, mask_file, lbl, pixels, f"{mean_hu:.2f}" if not np.isnan(mean_hu) else "NaN"])

    # 写 CSV
    try:
        with open(output_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(rows)
        print(f"逐标签区域 HU 统计已保存至: {output_csv}")
    except Exception as e:
        print(f"警告：写入 CSV 失败: {e}")


if __name__ == "__main__":

    calculate_label_regions_hu(
        ct_dir=r"E:\dataset\MAT\终极任务\第一个队列完整椎体切片\第一个队列完整椎体切片_dcm",
        mask_dir=r"E:\dataset\MAT\终极任务\第一个队列完整椎体切片\第一个队列完整椎体切片_png_mask",
        output_csv=r"E:\dataset\MAT\终极任务\第一个队列完整椎体切片\CT_label_HU.csv"
    )