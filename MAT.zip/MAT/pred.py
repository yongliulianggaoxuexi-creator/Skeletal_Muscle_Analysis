import os
import torch
os.environ["NO_ALBUMENTATIONS_UPDATE"] = "1"
import albumentations as A
from torch.utils.data import DataLoader
from tqdm import tqdm
from unetpp2 import NestedUNet
from model_mask2former import Mask2Former
import numpy as np
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

os.environ["ALBUMENTATIONS_DISABLE_VERSION_CHECK"] = "1"  # 禁用版本检查


# --------------------------------------
# 自定义数据集类（递归搜索子目录）
# --------------------------------------
class SegDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        """
        root_dir: 数据集根目录
        """
        self.image_dir = root_dir
        self.transform = transform

        # 递归收集所有 png 文件路径
        self.image_paths = []
        for root, _, files in os.walk(self.image_dir):
            for f in sorted(files):
                if f.endswith("png"):
                    self.image_paths.append(os.path.join(root, f))

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = Image.open(img_path).convert("RGB")
        image = np.array(image)

        if self.transform:
            augmented = self.transform(image=image)
            image = augmented["image"]

        image = transforms.ToTensor()(image)  # 归一化到 [0,1]
        return image, img_path  # 返回路径，方便后面保存


# --------------------------------------
# 测试并保存预测标签（保持子目录结构）
# --------------------------------------
def model_predict(model, data_loader, output_dir, device="cuda"):
    os.makedirs(output_dir, exist_ok=True)
    model = model.to(device)
    model.eval()

    with torch.no_grad():
        for images, paths in tqdm(data_loader, desc="预测"):
            images = images.to(device)
            outputs = model(images)

            preds = torch.argmax(outputs, dim=1)  # [B, H, W]
            preds_np = preds.cpu().numpy()

            for i, img_path in enumerate(paths):
                # 获取相对路径
                rel_path = os.path.relpath(img_path, data_loader.dataset.image_dir)
                save_path = os.path.join(output_dir, rel_path)

                # 创建对应子目录
                os.makedirs(os.path.dirname(save_path), exist_ok=True)

                # 保存预测图
                pred = preds_np[i]
                pred = np.where(pred == 2, 255, np.where(pred == 1, 127, 0)).astype(np.uint8)
                pred_image = Image.fromarray(pred, mode="L")
                pred_image.save(save_path)

    print(f"预测标签已保存至: {output_dir}")


# --------------------------------------
# 主函数
# --------------------------------------
def main():
    root_dir = r"E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片_png"
    output_dir = r"E:\dataset\MAT\终极任务\第二个队列单层切片\第二个队列单层切片_png_pred"
    batch_size = 1

    transform = A.Compose([
        A.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))
    ])

    dataset = SegDataset(root_dir=root_dir, transform=transform)
    data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=8)

    model = Mask2Former(n_channels=3, n_classes=3)

    model.load_state_dict(torch.load("checkpoints/best_model_mask2former_end_50.pth", map_location="cuda"))
    print("已加载模型参数: checkpoints/best_model_mask2former_end_50.pth")

    model_predict(model, data_loader, output_dir, device="cuda")


if __name__ == "__main__":
    main()
